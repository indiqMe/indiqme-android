package me.indiq.dev.indiqme.Activities

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProvider
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.view.View
import androidx.navigation.NavigatorProvider
import kotlinx.android.synthetic.main.activity_register.*
import me.indiq.dev.indiqme.R
import me.indiq.dev.indiqme.viewmodel.RegistroViewModel

class RegisterActivity : BaseActivity() {

    val viewModel: RegistroViewModel by lazy<RegistroViewModel> {
        ViewModelProviders.of(this).get(RegistroViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        setupToolbar(getString(R.string.cadastre_se))

        viewModel.currentPageLiveData().observe(this, Observer {
            text_etapa.text = "Etapa $it de 4"



            btn_voltar.visibility = (if (it == 1) View.GONE else View.VISIBLE)

            btn_avancar.visibility = (if (it == 4) View.GONE else View.VISIBLE)


        })

        btn_avancar.setOnClickListener {
            viewModel.pushPage()
        }

        btn_voltar.setOnClickListener {
            viewModel.popPage()
        }
    }


}
