# indiqme-android
Projeto mobile Android nativo com kotlin. Código livre.
